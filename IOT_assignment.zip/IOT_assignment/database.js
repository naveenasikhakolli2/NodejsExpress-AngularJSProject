let express = require('express');
let app = express();
// database configuration
let mysql = require('mysql');
let db = mysql.createConnection(
 {
  host: 'localhost',
  user: 'root',
  password: 'root',
  database: 'customerdb',
  insecureAuth : true
 });

 var sql = "CREATE TABLE Locations (locId INT AUTO_INCREMENT PRIMARY KEY, locAddress VARCHAR(255), city VARCHAR(255));"
 var sql2 = "CREATE TABLE Customers (custId INT AUTO_INCREMENT PRIMARY KEY,custName VARCHAR(255),custLocation INT, FOREIGN KEY (custLocation) REFERENCES Locations(locId));"
 var sql3 = "CREATE TABLE Parcels (parcelId INT AUTO_INCREMENT PRIMARY KEY,weight VARCHAR(255),custId INT,FOREIGN KEY (custId) REFERENCES Customers(custId), finalLocation INT, FOREIGN KEY (finalLocation) REFERENCES Locations(locId));"
 
 var sql4 ="CREATE TABLE Located(parcelId INT, locId INT, date  DATE, Time TIME, operation VARCHAR(255),FOREIGN KEY (parcelId) REFERENCES Parcels(parcelId),FOREIGN KEY (locId) REFERENCES Locations(locId));" 
     
 const arr = [sql,sql2,sql3,sql4];

 db.connect(function(err) {
  if (err) throw err;
  var sql = "DROP TABLE IF EXISTS Customers, Parcels, Located, Locations";
  db.query(sql, function (err, result) {
    if (err) throw err;
    console.log("Tables deleted");
    arr.forEach(function(entry)
      {
        caller(entry);
      });
      var tab1 = "INSERT INTO Locations (locAddress, city) VALUES ?";
var values1 = [
  ['Nehru street','Chennai' ],
  ['Ganesh street', 'Annanagar'],
  ['Baba street', 'Coimbatore' ],
  ['Modi street', 'Besan nagar']
]; 
db.query(tab1, [values1], function(err) {
    if (err) throw err;
    console.log('Values added in tab1');
});

var tab2 = "INSERT INTO Customers (custName, custLocation) VALUES ?";
var values2 = [
  ['demian',1 ],
  ['john', 2],
  ['mark',3 ],
  ['pete', 4]
];
db.query(tab2, [values2], function(err) {
  if (err) throw err;
  console.log('Values added in tab2');
});
var tab3 = "INSERT INTO Parcels (weight, custId, finalLocation) VALUES ?";
var values3 = [
  ['2kg',1, 2],
  ['3kg',2, 3],
  ['1kg',3, 4],
  ['2kg', 4, 1]
]; 
db.query(tab3, [values3], function(err) {
    if (err) throw err;
    console.log('Values added in tab3');
});

var tab4 = "INSERT INTO Located (parcelId,locId, date, time, operation) VALUES ?";
var values4 = [
  [1, 1, '2019-2-11', '20:11:12','boarding'],
  [2, 2, '2019-5-10', '10:22:23' , 'transfer'],
  [3, 3, '2019-4-22', '21:15:45', 'transfer'],
  [4, 4, '2019-6-12', '11:25:56', 'boarding']
  [5, 5, '2019-7-02', '12:45:32', 'boarding']
]; 
db.query(tab4, [values4], function(err) {
    if (err) throw err;
    console.log('Values added in tab4');
});
 
  });
});


function caller(sql)
{
db.query(sql, function (err, result) {
	if (err) throw err;
	console.log("Table created");
});
}



// load routes: define controller which act on db
let routes = require('./routes.js');
routes(app, db);

// run server  
app.listen(3000);

 





