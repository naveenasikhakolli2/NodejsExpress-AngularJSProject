

locApp = angular.module('angLocApp', []);

locApp.controller('LocationsListController',  function($scope, $http) {
	
	let URL_ALL_LOCS = "http://localhost:3000/getAllParcels";
        let URL_INSERT_LOC = "http://localhost:3000/insLocation?";
	let URL_UPDATE_PAR = "http://localhost:3000/updLocation?";
        let URL_DELETE_LOC = "http://localhost:3000/delParcel?";
        
        
	$scope.viewFormUpdate = false;
    
	$scope.located = [];
			
	$http.get(URL_ALL_LOCS).then(function(response) {
	
      $scope.located =  response.data;
	  
    });
    
    
        $scope.showUpdateFormLocation = function(location) {
		$scope.viewFormUpdate = true;
		
		$scope.updParcelId = location.parcelId;
		$scope.updLocation = angular.copy(location);
	}
        
        $scope.updateLocation = function() {
            let updRawLoc = {};
            let updLoc ={};
            let index;

            
            var locaid = $scope.updLocation.locId;
            var dat = $scope.updLocation.date;
            var tim = $scope.updLocation.time;
            var optn = $scope.updLocation.operation;

            $http.get(URL_UPDATE_PAR + `updId=${$scope.updParcelId}&updLocid=${locaid}&updDate=${dat}&updTime=${tim}&updOperation=${optn}`)
            //$http.get(URL_UPDATE_PAR + `updId=${$scope.updParcelId}&updLocid=${locaid}&updTime=${tim}&updOperation=${optn}`)
                                                .then(function (response) {
                updRawLoc = response.data;

                updLoc = {"parcelId":updRawLoc.id, "locId":updRawLoc.locationid,"date":updRawLoc.datu,"time":updRawLoc.timu,"operation": updRawLoc.operation};
                                                        //"date": updRawLoc.date,"time": updRawLoc.time,

                index = $scope.located.findIndex(l => l.parcelId === $scope.updParcelId);
                if(index !== undefined) {
                        $scope.located[index] = $scope.updLocation;

                }	
                $scope.viewFormUpdate = false;

            });
	}
        $scope.cancelUpdate = function(location) {
		$scope.viewFormUpdate = false;
		
		$scope.updParcelId = undefined;

	}
        
	
       $scope.showConfirmDeleteLocation = function(location) {
		let okDelete = false;
		
		$scope.viewFormUpdate = false;
		okDelete = window.confirm("Delete Located : " + location.locId + " - " 
						+ 	location.operation + "(" + location.parcelId + ")");
						
		if(okDelete == true) {
			$http.get(URL_DELETE_LOC + `delId=${location.parcelId}`)
				.then(function (response) {
				
		
				index = $scope.located.findIndex(l => l.parcelId === location.parcelId);
				if(index !== undefined) {
					$scope.located.splice(index, 1);
				}				
		        })
		}
	}
	
});