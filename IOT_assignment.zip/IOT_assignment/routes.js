module.exports = (app, db) => {


let ejs = require('ejs');
var bodyParser = require('body-parser');

app.use(bodyParser.urlencoded({ extended: false }));

app.set('view engine', 'html');
app.engine('html', ejs.renderFile);

app.get('/', function(req, res){
    res.setHeader('Content-Type', 'text/html');
    res.render('home');
 });

app.get('/createParcel',function(req, res){
    
    let sql1 = 'SELECT * FROM Customers';
    let sql2 = 'SELECT * FROM Locations';
    db.query(sql1, function(err, investors){
        if (err) throw err; //you should use this for error handling when in a development environment
        console.log(investors); //this should print

        db.query(sql2, function(err, members) {
            if (err) throw err;
            console.log(members);

            res.render('createNewParcel', {data:investors, data1:members});
        });  
    });
   
 });

app.post('/addToList',function(req, res){
    let weight = (req.body.weight);
    let custId =(req.body.custId);
    let finalLocation = (req.body.finalLocation);

    let sql = 'INSERT INTO Parcels(weight, custId, finalLocation) VALUES(?, ?, ?)';
    let sql1 = 'SELECT * from Parcels, Customers, Locations where Parcels.custId = Customers.custId and Parcels.finalLocation = Locations.LocId;';
    
    let values = [weight, custId, finalLocation];
    //console.log(values)
    let postProcessInsert =   function (err, rows, result) {
        if (err) throw err;
        console.log(err);
    };
    let callback =   function (err, rows, result) {
        if (err) throw err;
        res.setHeader('Content-Type', 'text/html');
        res.render('displayNewParcel', {data:rows});
    };

    db.query(sql, values, postProcessInsert);
    db.query(sql1, callback);

});

app.get('/displayParcel', function(req, res){

    let sql_id = 'SELECT Distinct custId from Customers';
    //let sql = 'SELECT parcelId, weight, finalLocation from Parcels';
    
    let postProcessInsert =   function (err, rows, result) {
        if (err) throw err;
        res.setHeader('Content-Type', 'text/html');
        res.render('displayCustomerList', {data: rows});
        }
    db.query(sql_id, postProcessInsert)

    });   
app.get('/ShowParcelList', function(req, res){
    let custId = (req.query.custId);
    let sql = ' select parcelId, weight, custName from Parcels, customers where Parcels.custId = ? and Parcels.custId = Customers.custId;' ;
    let callback = function(err, rows, result) {
        if (err) throw err;
        res.setHeader('Content-type', 'text/html');
        res.render('displayParcelList', {data:rows});
    }
    db.query(sql, [custId] ,callback);

});
        



//server with angular

app.get('/parcel', function(req, res) {
     
	// send the main (and unique) page
    res.setHeader('Content-Type', 'text/html');
    res.sendFile( __dirname + '/views' + '/ngParcels.html');
});

app.get('/ngParcels.js', function(req, res) {
     
	// send the angular app
    res.setHeader('Content-Type', 'application/javascript');
    res.sendFile( __dirname + '/js' + '/ngParcels.js');
});

app.get('/getAllParcels', function(req, res) {
     
		let sql = "SELECT parcelId, locId,(DATE_FORMAT(date, '%Y-%m-%d')) as date, time,operation FROM located";
		

		// response contains a json array with all tuples
		let postProcessSQL =   function (err, result) {
			if (err) throw err;

			res.json(result);
		};
  
		db.query(sql, postProcessSQL);
	
        
});



app.get('/updLocation', function(req, res) {
    
        let id=(req.query.updId);
        let locationid=(req.query.updLocid);
        let datu=(req.query.updDate);
        let timu=(req.query.updTime);
        let operation= (req.query.updOperation);
        
		let sql = 'UPDATE located SET locId = ?,date = ?,time = ?,operation = ? WHERE parcelId = ?';
		let values = [ locationid,datu,timu,operation,id];

		// create a json object containing the inserted location
		let postProcessUpdate =   function (err, result) {
			if (err) throw err;

                    console.log({
			          id: result.insertId,locationid:locationid,datu:datu,timu:timu,
                                   operation:operation,insertedLines: result.affectedRows });
                               
			res.json({id:id, locationid:locationid,datu:datu,
                            timu:timu,operation:operation,insertedLines: result.affectedRows });
		};
  
		db.query(sql, values, postProcessUpdate);
 
		});
                
app.get('/delParcel', function(req, res) {
            	let id = (req.query.delId);
 
		let sql = 'DELETE FROM located WHERE parcelId = ?';
		let values = [id];

		// create a json object containing the number of deleted locations
		let postProcessDelete =   function (err, result) {
			if (err) throw err;

			res.json({deletedLines: result.affectedRows });
		};
  
		db.query(sql, values, postProcessDelete);
 
		
});

                
}